class first
{	
	String s="Vivek MCA";//instance variable

	public static void main(String [] args)
	{	
		first f=new first();//creating an abject
		System.out.println("Welcome to"+f.s+"\n");//variable is called with the object
	}
}