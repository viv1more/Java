public class fivetab
{
	public static void main(String[] args)
{	 
	 int a=5;
	for(int i=1;i<=10;i++)
	{
		
	System.out.println(i*a);
	}
	
}
}