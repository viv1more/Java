class fourth
{	
	int a=5;
	int b=6;
	void addition()
	{
				System.out.println("Addition of "+a+" and "+b+" is "+(a+b));
	}
	public static void main(String[] args) 
	{	
		fourth s = new fourth();
		s.addition();
	}
}
