public class addition
{
	public static void main(String[] args)
{	
	int a=10;
	int b=5;
	int c;
	c=a+b;
	System.out.println("Addition= "+c);
	
}
}