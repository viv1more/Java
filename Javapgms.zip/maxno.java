public class maxno
{
	public static void main(String[] args)
{	
	int a,b,c;
	a=89;
	b=76;
	c=32;
	if(a>b && a>c)
	{
		System.out.println("a is maximum number");
	}
	if(b>a && b>c)
	{
		System.out.println("b is maximum number");
	}
	if(c>b && c>a)
	{
		System.out.println("c is maximum number");
	}
	
	
}
}