class second 
{
	String a;
	int b;
	boolean bl;
	float ff;
	double d;
	public static void main(String[] args) 
	{		
		second f=new second();
		System.out.println("The Values are....\n\n");
		System.out.println("A="+f.a+" is good");
		System.out.println("B="+f.b);
		System.out.println("Boolean ="+f.bl);
		System.out.println("Float="+f.ff);
		System.out.println("Double="+f.d);
	}
}
