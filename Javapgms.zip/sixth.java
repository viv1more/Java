class sixth 
{
	void display(String s,int age)
	{
		System.out.println("Name="+s+"  Age="+age+"\n");
	}
	public static void main(String[] args) 
	{
		sixth s=new sixth();
		s.display("Vivek",21);
	}
}
