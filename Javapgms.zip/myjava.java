public class myjava
{
	public static void main(String[] args)
{
	System.out.println("Vivek Ashok More");
	System.out.println("Chalisgaon 424101");
}
}