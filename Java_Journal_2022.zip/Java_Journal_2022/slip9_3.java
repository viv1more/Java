		
//implementing null pointer exception
//it is nothing but an error which occurs if we tried ti perform any operation on object which is null

public class slip9_3
 {
     public static void main(String [] args)
	 {
		 String str = null;
		 System.out.println(str.length());
	 }
 }	 
