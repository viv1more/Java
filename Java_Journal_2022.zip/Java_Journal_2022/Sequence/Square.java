package Sequence;
import java.util.*;
public class Square 
{
    public void show1()
  {
  //int x =1;
   int n1;
   Scanner sc= new Scanner(System.in);
   System.out.println("Enter value of n1:");
   n1=sc.nextInt();
   for(int i=1;i<=n1;i++)
   {
      //x = ((i));
	  System.out.println("Square is: "+(i*i));
	
   }
  
  }

}
