import Sequence.Fact;
public class slip2_2
 {
   
  public static void main(String [] args)
  {
    Fact f = new Fact();
	  
	   f.show();
  }


}
