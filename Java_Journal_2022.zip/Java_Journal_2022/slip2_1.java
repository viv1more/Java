import Sequence.Square;
public class slip2_1 
{
    public static void main(String [] args)
    {
        
        Square s = new Square();
         s.show1();
        
    }
  
}
